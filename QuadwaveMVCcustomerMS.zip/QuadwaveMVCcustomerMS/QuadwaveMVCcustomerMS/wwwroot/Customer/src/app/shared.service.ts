import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Customer } from './customer/Customer.Model';
import { CustomerAddress } from './cust-address/CustAddress.Model';



@Injectable({
  providedIn: 'root'
})
export class SharedService {
  constructor(private http:HttpClient){}

  readonly ApiUrl="https://localhost:5000/api/customer";
  readonly baseURL="https://localhost:5000/api/CustomerAddress";

 formData:Customer=new Customer();
 list:Array<Customer>= new Array<Customer>();

 formCust:CustomerAddress=new CustomerAddress();
 custlst:Array<CustomerAddress>= new Array<CustomerAddress>();

 postCustDetails(){
   return this.http.post(this.ApiUrl,this.formData)
 }
putCustDetails(){
  return this.http.put('${this.ApiUrl}/${this.formData.CustomerId}',this.formData);
}
deleteCustDetails(){
  return this.http.delete('${this.baseUrl}/${CustomerId}');
}

refreshList(){
  this.http.get(this.ApiUrl)
  .toPromise()
  .then(res=>this.list = res as Customer[

  ])

  
}
refAddList(){
  this.http.get(this.baseURL)
  .toPromise()
  .then(res=>this.custlst=res as CustomerAddress[])
}
}
  

