﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using QuadwaveCustomerMS.Data;
using QuadwaveCustomerMS.DTOS;
using QuadwaveCustomerMS.Models;
using AutoMapper;
using QuadwaveCustomerMS.Profiles;

namespace QuadwaveCustomerMS.Profiles
{
    public class CustomerProfile:Profile
    {
        public CustomerProfile()
        {
            CreateMap<CustomerCreateDto, Customer>();
            CreateMap<Customer, CustomerReadDto>();
            CreateMap<CustomerUpdateDto, Customer>();
            CreateMap<CustomerDeleteDto, Customer>();

            CreateMap<CustomerAddress, CustomerAddressReadDto>();
            CreateMap<CustomerAddressCreateDto, CustomerAddress>();
            CreateMap<CustomerAddressUpdateDto, CustomerAddress>();
            CreateMap<CustomerAddressDeleteDto, CustomerAddress>();

        }
    }
}
