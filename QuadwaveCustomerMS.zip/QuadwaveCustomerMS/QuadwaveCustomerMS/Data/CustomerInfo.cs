﻿using QuadwaveCustomerMS.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QuadwaveCustomerMS.Data
{
    public class CustomerInfo : ICustomerInfo
    {
        private readonly CustomerContext _context;

        public CustomerInfo(CustomerContext context)
        {
            _context = context;
        }

        public Customer GeCustomer(int Id)
        {
            var customer = _context.Customer.SingleOrDefault(m => m.CustomerId == Id);
            return customer;
        }
        public List<Customer> GetCustomers()
        {
            var customer = _context.Customer.ToList();
            return customer;
        }

        public List<Customer> GetCustomer()
        {
            var customer = _context.Customer.ToList();
            return customer;
        }

        public Customer CreateCustomer(Customer c)
        {
            _context.Customer.Add(c);
            _context.SaveChanges();
            return c;
        }
        public void UpdateCustomer(Customer c)
        {
            _context.SaveChanges();
        }

        public void DeleteCustomer(Customer c)
        {
            _context.Remove(c);
            _context.SaveChanges();
        }




        public List<CustomerAddress> GetCustomerAddress()
        {
            var customerAdd = _context.CustomerAdresses.ToList();
            return customerAdd;
        }

        public CustomerAddress CreateCustomerAddress(CustomerAddress c)
        {
            _context.CustomerAdresses.Add(c);
            _context.SaveChanges();
            return c;
        }

        public void UpdateCustomerAddress(CustomerAddress c)
        {
            _context.SaveChanges();
        }
        public void DeleteCustomerAddress(CustomerAddress c)
        {
            _context.Remove(c);
            _context.SaveChanges();
        }

        public CustomerAddress GetCustomerAddress(int id)
        {
            var customers = _context.CustomerAdresses.SingleOrDefault(m => m.Id == id);
            return customers;
        }

    }
}
