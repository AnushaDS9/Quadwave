﻿using QuadwaveCustomerMS.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QuadwaveCustomerMS.Data
{
   public interface ICustomerInfo
    {
        public Customer GeCustomer(int Id);
        public List<Customer> GetCustomers();

        public Customer CreateCustomer(Customer c);
        public void UpdateCustomer(Customer c);
        public void DeleteCustomer(Customer c);

        public List<CustomerAddress> GetCustomerAddress();
        public CustomerAddress GetCustomerAddress(int id);

        public CustomerAddress CreateCustomerAddress(CustomerAddress c);
        public void UpdateCustomerAddress(CustomerAddress c);
        public void DeleteCustomerAddress(CustomerAddress c);

    }
}
