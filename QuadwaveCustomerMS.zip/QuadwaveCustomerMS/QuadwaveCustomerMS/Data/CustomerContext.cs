﻿using QuadwaveCustomerMS.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;


namespace QuadwaveCustomerMS.Data
{
   
        public class CustomerContext : Microsoft.EntityFrameworkCore.DbContext
        {
            public CustomerContext(Microsoft.EntityFrameworkCore.DbContextOptions<CustomerContext> opt) : base(opt)
            {

            }


            public DbSet<Customer> Customer{ set; get; }
        public DbSet<CustomerAddress> CustomerAdresses { set; get; }


        }
    
}
