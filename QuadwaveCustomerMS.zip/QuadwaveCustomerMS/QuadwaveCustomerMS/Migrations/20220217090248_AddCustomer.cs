﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace QuadwaveCustomerMS.Migrations
{
    public partial class AddCustomer : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql("Insert  into Customer values('Anusha','Ravish','2/17/2022')");
            migrationBuilder.Sql("Insert  into Customer values('Deepika','Ranganna','2/18/2022')");
            migrationBuilder.Sql("Insert  into Customer values('Renuka','Yadagi','2/19/2022')");
            migrationBuilder.Sql("Insert  into Customer values('Thanu','Sadashiv','2/20/2022')");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
