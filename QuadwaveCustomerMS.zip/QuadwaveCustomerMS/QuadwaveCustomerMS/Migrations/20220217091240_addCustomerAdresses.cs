﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace QuadwaveCustomerMS.Migrations
{
    public partial class addCustomerAdresses : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql("Insert  into CustomerAdresses values(1,'India','Mysore','jp nagar','8971970350')");
            migrationBuilder.Sql("Insert  into CustomerAdresses values(2,'India','Manglore','yy street','6121456987')");
            migrationBuilder.Sql("Insert  into CustomerAdresses values(3,'India','Banglore','xx Street','7002225000')");
            migrationBuilder.Sql("Insert  into CustomerAdresses values(5,'India','Mandya','jp nagar','8456324569')");
            migrationBuilder.Sql("Insert  into CustomerAdresses values(6,'India','CH Nagar','jp nagar','8012004569')");


        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
