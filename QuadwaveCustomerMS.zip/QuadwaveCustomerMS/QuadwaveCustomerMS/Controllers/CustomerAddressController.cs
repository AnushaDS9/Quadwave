﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using QuadwaveCustomerMS.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using QuadwaveCustomerMS.DTOS;
using QuadwaveCustomerMS.Models;

namespace QuadwaveCustomerMS.Controllers
{

    [ApiController]
    [Route("api/[controller]")]
    public class CustomerAddressController : Controller
    {
        private ICustomerInfo _info;
        private IMapper _mapper;

        public CustomerAddressController(ICustomerInfo info, IMapper mapper)
        {
            _info = info;
            _mapper = mapper;
        }
        [HttpGet]

        public ActionResult<IEnumerable<CustomerAddressReadDto>> GetCustomerAddress()
        {
            var add = _info.GetCustomerAddress();
            return Ok(_mapper.Map<List<CustomerAddressReadDto>>(add));
        }
        [HttpGet("{id}")]

        public ActionResult<CustomerAddressReadDto> GeCustomerAddress(int id)
        {
            var add = _info.GetCustomerAddress(id);
            return Ok(_mapper.Map<CustomerAddressReadDto>(add));
        }

        [HttpPost]
        public ActionResult<CustomerAddressReadDto> CreateCustomerAddress(CustomerAddressCreateDto customerAddressCreateDto)
        {
            if (customerAddressCreateDto != null)
            {
                var newCust = _mapper.Map<CustomerAddress>(customerAddressCreateDto);
                _info.CreateCustomerAddress(newCust);
                return Ok(customerAddressCreateDto);
            }
            else
            {
                return NotFound();
            }
        }

        [HttpPut("{id}")]

        public ActionResult<CustomerAddressReadDto> UpdateCustomerAddress(int id, CustomerAddressUpdateDto customerAddressUpdateDto)
        {
            var newCust = _info.GetCustomerAddress(id);
            if (customerAddressUpdateDto == null)
            {
                return NotFound();
            }
            else
            {
                _mapper.Map(customerAddressUpdateDto, newCust);
                _info.UpdateCustomerAddress(newCust);
                return Ok(customerAddressUpdateDto);
            }
        }

        [HttpDelete("{id}")]
        public ActionResult<CustomerAddressReadDto> DeleteCustomerAddress(int id, CustomerAddressDeleteDto customerAddressDeleteDto)
        {
            var newCust = _info.GetCustomerAddress(id);

            if (customerAddressDeleteDto != null)
            {
                _mapper.Map(customerAddressDeleteDto, newCust);
                _info.DeleteCustomerAddress(newCust);
                return Ok(customerAddressDeleteDto);
            }
            else
            {
                return NotFound();
            }
        }
    }
}
