﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using QuadwaveCustomerMS.Data;
using QuadwaveCustomerMS.DTOS;
using QuadwaveCustomerMS.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QuadwaveCustomerMS.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class CustomerController : Controller
    {
        private readonly ICustomerInfo _info;
        private readonly IMapper _mapper;

        public CustomerController(ICustomerInfo info, IMapper mapper)
        {
            _info = info;
            _mapper = mapper;
        }

        [HttpGet("{id}")]

        public ActionResult<CustomerReadDto> GeCustomer(int id)
        {
            var customer = _info.GeCustomer(id);
            return Ok(_mapper.Map<CustomerReadDto>(customer));
        }

        [HttpGet]

        public ActionResult<IEnumerable<CustomerReadDto>> GetCustomer()
        {
            var customer = _info.GetCustomers();
            return Ok(_mapper.Map<IEnumerable<CustomerReadDto>>(customer));
        }

        [HttpPost]
        public ActionResult<CustomerReadDto> CreateCustomer(CustomerCreateDto customerCreateDto)
        {
            if (customerCreateDto != null)
            {
                var newCust = _mapper.Map<Customer>(customerCreateDto);
                _info.CreateCustomer(newCust);
                return Ok(customerCreateDto);
            }
            else
            {
                return NotFound();
            }
        }

        [HttpPut("{id}")]

        public ActionResult<CustomerReadDto> UpdateCustomer(int id, CustomerUpdateDto customerUpdateDto)
        {
            var newCust = _info.GeCustomer(id);
            if (customerUpdateDto == null)
            {
                return NotFound();
            }
            else
            {
                _mapper.Map(customerUpdateDto, newCust);
                _info.UpdateCustomer(newCust);
                return Ok(customerUpdateDto);
            }
        }

        [HttpDelete("{id}")]
        public ActionResult<CustomerReadDto> DeleteCustomer(int id, CustomerDeleteDto customerDeleteDto)
        {
            var newCust = _info.GeCustomer(id);

            if (customerDeleteDto != null)
            {
                _mapper.Map(customerDeleteDto, newCust);
                _info.DeleteCustomer(newCust);
                return Ok(customerDeleteDto);
            }
            else
            {
                return NotFound();
            }
        }
    }
}
