﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QuadwaveCustomerMS.DTOS
{
    public class CustomerCreateDto
    {
        
        public string FirstName { set; get; }
        public string LastName { set; get; }
        public DateTime CreatedDate { set; get; }
    }
}
