﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QuadwaveCustomerMS.DTOS
{
    public class CustomerAddressUpdateDto
    {
        public string Country { set; get; }
        public string City { set; get; }
        public string StreetAddress { set; get; }
        public string Phone { set; get; }

    }
}
